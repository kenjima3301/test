package com.example.mobileapp;

import android.app.Activity;

public class ChangepassFragment extends Activity {
}
