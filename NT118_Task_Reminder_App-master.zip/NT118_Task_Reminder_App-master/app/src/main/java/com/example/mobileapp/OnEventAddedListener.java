package com.example.mobileapp;

public interface OnEventAddedListener {
    void onEventAdded(Event event);
}
