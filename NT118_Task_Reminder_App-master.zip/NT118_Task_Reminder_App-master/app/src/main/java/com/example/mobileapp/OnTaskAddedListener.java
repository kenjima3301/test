package com.example.mobileapp;

public interface OnTaskAddedListener {
    void onTaskAdded(Task task);
}
