package com.example.mobileapp;

public class HelpAndFeedback {
    private int feedback_id;
    private int userId;
}
