package com.example.mobileapp;

import android.app.Activity;

public class NotiSoundFragment extends Activity {
}
