package com.example.mobileapp;

import android.app.Activity;

public class SignupFragment extends Activity {
}
